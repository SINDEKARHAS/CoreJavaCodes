import { Component } from '@angular/core';
import { UserservService } from './userserv.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ErrorHandling';
  load?:boolean
  error?:string

    constructor(private usrserv:UserservService)
    {
    }

    getListUsers()
    {
      this.load=true;
      this.usrserv.getUsers().subscribe(
            u => {console.log(u)
              this.load=false;
            },
            err=>{
              this.error = err
              this.load=false
            }
        )

    }







}
