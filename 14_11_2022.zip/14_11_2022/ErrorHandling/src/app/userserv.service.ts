import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable,throwError } from 'rxjs'
import { user } from './user';
import { catchError,retry } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class UserservService {

  url = "https://localhost:8080/getlistusers"

  constructor(private http:HttpClient)
  { }

  getUsers():Observable<user[]>
  {
    return this.http.get<user[]>(this.url).
    pipe(
        retry(1),
        catchError(this.handlerError)
        );
  }

  handlerError(error:any)
  {
    let ermsg='';
    if(error.error instanceof ErrorEvent)
      {
          ermsg = `Error : ${error.message} `
      }
      else  {
          ermsg = ` Error Code : ${error.status} \n Message: ${error.message}`
      }
      window.alert(ermsg)
      return throwError(ermsg)
  }




}
