import { Component } from '@angular/core';
import { CustomservService } from './customserv.service';
import { Employee } from './Employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Promise_Observable';

  forsubscribeEmployee?:Employee[]=[]
  forpromiseEmployee?:Employee[]=[]

constructor(private myserv: CustomservService)
{
this.getallEmployeesubsscribe();
this.getEmployeeViaPromise();
}

getallEmployeesubsscribe()
{
  this.myserv.getEmployee_Subscription().subscribe(
      res => {
        this.forsubscribeEmployee = res;
        console.log(this.forsubscribeEmployee)
      },
        er=>{console.log(er);}
  );
}

getEmployeeViaPromise()
{
    this.myserv.getEmployee_ForPromise().toPromise().then(
      res =>{
          this.forpromiseEmployee=res
          console.log(this.forpromiseEmployee)
      }).catch(err=>{console.log(err)})

}
}
