import { Injectable } from '@angular/core';
import { Observable } from 'rxjs'
import { observeNotification } from 'rxjs/internal/Notification';
import { Employee } from './Employee';


@Injectable({
  providedIn: 'root'
})
export class CustomservService {

  mydata?: Employee []=[
    {id:101,name:'Pooja'},
    {id:102,name:'Mohan'}
  ]

  constructor() { }

  myobserv?:Observable<Employee[]>=new Observable<Employee[]>()

getEmployee_Subscription():Observable<Employee[]>
{
    return new Observable<Employee[]>( obsv =>{
                                                    setTimeout( () =>
                                                      {obsv.next(this.mydata)},2000);

                                                });

}

getEmployee_ForPromise():Observable<Employee[]>
{
   return new Observable<Employee[]>( obsv =>{
                                                    setTimeout( () =>
                                                      {
                                                        obsv.next(this.mydata);
                                                        obsv.complete();

                                                      },2000);
                                                });

}






}
