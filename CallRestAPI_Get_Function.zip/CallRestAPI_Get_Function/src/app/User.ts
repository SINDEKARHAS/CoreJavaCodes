export class User
{
  public usrid?:number
  public usrname?:string
  public pwd?:string 
}