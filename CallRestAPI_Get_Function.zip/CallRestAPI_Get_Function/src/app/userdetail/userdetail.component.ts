import { Component, OnInit } from '@angular/core';
import { UserservService } from '../userserv.service';
import { User } from '../User';
@Component({
  selector: 'app-userdetail',
  templateUrl: './userdetail.component.html',
  styleUrls: ['./userdetail.component.css']
})
export class UserdetailComponent implements OnInit {

  p?:User[]=[]
  constructor(private userv : UserservService) { }

  ngOnInit(): void 
  {
      this.getallusers()
  }

  getallusers()
  {
    this.userv.getUser().subscribe(
      (u:User |any)=>
      {
      this.p = u;
      console.log(this.p);
      },
      (e: any)=>{console.log(e)}
  );

    
  }

}
