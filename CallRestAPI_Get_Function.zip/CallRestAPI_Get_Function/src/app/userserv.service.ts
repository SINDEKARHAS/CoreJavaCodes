import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { User } from './User';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserservService
{
  //url:string ="http://localhost:8080/getusers"

  data:string

  constructor(private http:HttpClient) 
  { 
    this.data ="[{usrid:101,usrname:'pooja',pwd:'1234'},{usrid:102,usrname:'mohan',pwd:'2345'}]"
  }

  

getUser(): Observable<any>
{
  return this.http.get<User>(this.data);
}
}
