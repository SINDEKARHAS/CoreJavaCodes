import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminpanelComponent } from './adminpanel/adminpanel.component';
import { RouterModule } from '@angular/router';
import { CustomerpanelComponent } from './customerpanel/customerpanel.component';
import { CartComponent } from './cart/cart.component';
import { PrdtlistComponent } from './prdtlist/prdtlist.component';
import { SearchProductComponent } from './search-product/search-product.component';
import { AddProductComponent } from './add-product/add-product.component';


@NgModule({
  declarations: [
    AppComponent,
    AdminpanelComponent,
    CustomerpanelComponent,
    CartComponent,
    PrdtlistComponent,
    SearchProductComponent,
    AddProductComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,ReactiveFormsModule,RouterModule,

    RouterModule.forRoot([
      {path: 'admin', component:AdminpanelComponent},
      {path: 'customer', component:CustomerpanelComponent },
      {path: '', redirectTo: '/customer', pathMatch: 'full'},
      {path: 'viewcart', component:CartComponent},
      {path: 'productlist', component: PrdtlistComponent },
      {path: 'addproduct', component: AddProductComponent },
      {path: 'searchprdt/:id', component:SearchProductComponent }

    ])



  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }


 // {path: '', redirectTo: '/home', pathMatch: 'full' },
    //  {path: 'login', component:LoginComponent},
     // {path: 'registration', component:RegistrationComponent},
    //  ,
     // {path: 'contact', component:ContactComponent},
    //  {path: '**', component:PagenotfoundComponent},

  /*  children:[
      {path: 'productlist', component:PrdtlistComponent}
     ]*/
