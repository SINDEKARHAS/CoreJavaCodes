import { Component, EventEmitter, OnInit,Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from 'src/models/Product';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  
  st?:string |any
  pt?:Product[]=[]
  p: any
  s:number=0
  i:number=0

  constructor(private actrt : ActivatedRoute,private rt:Router) { }

  ngOnInit(): void
  {
    this.getdata();
  }

  getdata()
  {
    for(let i=0 ;i < localStorage.length ; i++)
    {
      this.st = localStorage.key(i)
      this.p = localStorage.getItem(this.st)
      let obj = JSON.parse(this.p)
      this.pt?.push(obj)
      this.s =this.s + obj['price'];
    }

  }

  deletecartitem(p:Product)
  {
    this.s=0
    this.st = p.prnm
    this.p = localStorage.getItem(this.st)
    localStorage.removeItem(this.st)
    this.pt?.splice(this.pt?.indexOf(p),1);
    this.calculatebill()

  }

  calculatebill()
  {
    for(this.i=0;this.i < localStorage.length;this.i++)
    {
      this.st = localStorage.key(this.i)
      this.p = localStorage.getItem(this.st)
      let obj = JSON.parse(this.p)
      this.s =this.s + obj['price'];

    }
  }



}
