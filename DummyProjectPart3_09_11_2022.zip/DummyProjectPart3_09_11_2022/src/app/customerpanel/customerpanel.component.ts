import { Component, OnInit } from '@angular/core';
import { MyserviceService } from 'src/services/myservice.service';
import { Product } from 'src/models/Product';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'app-customerpanel',
  templateUrl: './customerpanel.component.html',
  styleUrls: ['./customerpanel.component.css']
})
export class CustomerpanelComponent implements OnInit {

pd?:Product[]


  constructor(private myserv: MyserviceService,private actrt : ActivatedRoute,private rt:Router) { }

  ngOnInit(): void
  {
    this.pd = this.myserv.createProduct();
  }

cart(pd:Product | any)
{
  localStorage.setItem(pd.prnm,JSON.stringify(pd))
}

showcart()
{
this.rt.navigate(['/viewcart'])
}


}
