import { Component, OnInit } from '@angular/core';
import { MyserviceService } from 'src/services/myservice.service';
import { Product } from 'src/models/Product';

@Component({
  selector: 'app-prdtlist',
  templateUrl: './prdtlist.component.html',
  styleUrls: ['./prdtlist.component.css']
})
export class PrdtlistComponent implements OnInit {

  pt ?:Product[]=[]

  constructor(private myser:MyserviceService) { }

  ngOnInit(): void
  {
        this.pt = this.myser.createProduct();
  }
  

}
