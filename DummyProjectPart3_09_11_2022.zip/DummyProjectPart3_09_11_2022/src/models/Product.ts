export class Product
{
  public prid?:number
  public prnm?:string
  public qty?:number;
  public price?:number
  public description?:string
  public pic?:string
}
