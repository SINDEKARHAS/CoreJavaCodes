import { Injectable } from '@angular/core';
import { Product } from 'src/models/Product';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  prdt?:Product[] // multiple records

  constructor()
  {

  }


  createProduct():Product[]
  {
    this.prdt = [{prid:101,prnm:"Laptop 1",qty:10,price:100000,pic:"../assets/laptop1.jpg",description:"In laptops, the age of the CPU (Central processing unit) is known as the 'generation'. The newer generation of laptops is more developed, has more features, and is more power-efficient than the older ones."},
                  {prid:102,prnm:"Laptop 2",qty:5,price:90000,pic:"../assets/laptop2.jpg",description:"In laptops, the age of the CPU (Central processing unit) is known as the 'generation'. The newer generation of laptops is more developed, has more features, and is more power-efficient than the older ones."},
                  {prid:103,prnm:"Laptop 3",qty:3,price:980000,pic:"../assets/laptop3.jpg",description:"In laptops, the age of the CPU (Central processing unit) is known as the 'generation'. The newer generation of laptops is more developed, has more features, and is more power-efficient than the older ones."},
                  {prid:104,prnm:"Laptop 4",qty:7,price:760000,pic:"../assets/laptop4.jpg",description:"In laptops, the age of the CPU (Central processing unit) is known as the 'generation'. The newer generation of laptops is more developed, has more features, and is more power-efficient than the older ones."},
                  {prid:105,prnm:"Laptop 5",qty:5,price:50000,pic:"../assets/Laptop5.png",description:"In laptops, the age of the CPU (Central processing unit) is known as the 'generation'. The newer generation of laptops is more developed, has more features, and is more power-efficient than the older ones."},
                  {prid:106,prnm:"Laptop 6",qty:3,price:480000,pic:"../assets/Laptop6.png",description:"In laptops, the age of the CPU (Central processing unit) is known as the 'generation'. The newer generation of laptops is more developed, has more features, and is more power-efficient than the older ones."},
                  {prid:107,prnm:"Laptop 7",qty:7,price:960000,pic:"../assets/Laptop7.png",description:"In laptops, the age of the CPU (Central processing unit) is known as the 'generation'. The newer generation of laptops is more developed, has more features, and is more power-efficient than the older ones."}
                ]

    return this.prdt
  }

  searchproduct(id:number):Product |any
  {
  return this.prdt?.filter(
                    (m)=>m.prid == id)
  }


}
