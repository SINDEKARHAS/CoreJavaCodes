import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styles:[ 'body{margin: 20px 20px 20px 20px; padding:20px 20px 20px 20px}']
})
export class AppComponent {
  title = 'DummyProductPrj';


}
