import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from 'src/models/Product';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  st?:string |any
  pt?:Product[]=[]
  p: any

  constructor(private actrt : ActivatedRoute,private rt:Router) { }

  ngOnInit(): void
  {
    this.getdata();

  }

  getdata()
  {
    for(let i=0 ;i < localStorage.length ; i++)
    {
      this.st = localStorage.key(i)
      this.p = localStorage.getItem(this.st)
      let obj = JSON.parse(this.p)
      this.pt?.push(obj)
    }


  }

  deletecartitem(pt:Product)
  {
    this.st = pt.prnm
  this.p = localStorage.getItem(this.st)
   localStorage.removeItem(this.st)
   
  }

}
