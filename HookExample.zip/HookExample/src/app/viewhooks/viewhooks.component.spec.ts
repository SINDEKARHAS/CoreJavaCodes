import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewhooksComponent } from './viewhooks.component';

describe('ViewhooksComponent', () => {
  let component: ViewhooksComponent;
  let fixture: ComponentFixture<ViewhooksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewhooksComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewhooksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
