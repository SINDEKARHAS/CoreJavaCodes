import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewhooks',
  templateUrl: './viewhooks.component.html',
  styleUrls: ['./viewhooks.component.css']
})
export class ViewhooksComponent implements OnInit {

  constructor() { }


  ngOnChange()
  {
    console.log("OnChange")
  }

  ngOnInit(): void {
    console.log("onInit")
  }

  ngDoCheck()
  {
    console.log("doCheck")
  }

  ngAfterContentInit()
  {
    console.log("ngAfterContentInit")
  }

  ngAfterContentChecked()
  {
    console.log("ngAfterContentChecked")
  }
  ngAfterViewInit()
  {
    console.log("ngAfterViewInit")
  }
  ngAfterViewChecked()
  {
    console.log("ngAfterViewChecked")
  }




}
