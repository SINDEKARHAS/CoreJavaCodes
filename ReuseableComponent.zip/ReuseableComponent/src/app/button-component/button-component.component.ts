import { Component, OnInit,EventEmitter,Output } from '@angular/core';

@Component({
  selector: 'app-button-component',
  templateUrl: './button-component.component.html',
  styleUrls: ['./button-component.component.css']
})
export class ButtonComponentComponent implements OnInit {

  @Output() btnClicked=new EventEmitter<string>()

  text="Hello ! Button Child Component get called"

  constructor() { }

  ngOnInit(): void {
  }

  onButtonClicked()
  {
    this.btnClicked.emit(this.text)
  }

}
