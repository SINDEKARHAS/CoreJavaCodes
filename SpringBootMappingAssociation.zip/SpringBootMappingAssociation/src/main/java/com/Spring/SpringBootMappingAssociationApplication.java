package com.Spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMappingAssociationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMappingAssociationApplication.class, args);
	}

}
