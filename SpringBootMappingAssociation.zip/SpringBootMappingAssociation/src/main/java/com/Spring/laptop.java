package com.Spring;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name="laptop")
public class laptop 
{
	
	@Id
	@Column(name="laptopid")
	private int laptopid;
	
	@Column(name="laptopname")
	private String laptopname;
	
	@JsonIgnore
	@ManyToOne
	private student st;

	public int getLaptopid() {
		return laptopid;
	}

	public void setLaptopid(int laptopid) {
		this.laptopid = laptopid;
	}

	public String getLaptopname() {
		return laptopname;
	}

	public void setLaptopname(String laptopname) {
		this.laptopname = laptopname;
	}

	public student getSt() {
		return st;
	}

	public void setSt(student st) {
		this.st = st;
	}
		
}
