package com.Spring;
import javax.persistence.*;
import java.util.*;

@Entity
@Table(name="student")
public class student 
{
	
	@Id
	@Column(name="stid")
	private int stid;
	
	@Column(name="stnm")
	private String stnm;
	
	@OneToMany(mappedBy="st")
	private List<laptop> LP;

	public int getStid() {
		return stid;
	}

	public void setStid(int stid) {
		this.stid = stid;
	}

	public String getStnm() {
		return stnm;
	}

	public void setStnm(String stnm) {
		this.stnm = stnm;
	}

	public List<laptop> getLP() {
		return LP;
	}

	public void setLP(List<laptop> lP) {
		LP = lP;
	}
	
}
