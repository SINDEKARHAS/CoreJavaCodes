import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'TemplateDrivenForms';

  form = {
            fullname:'',
            username:'',
            email:'',
            password:'',
            confirmpassword:'',
          }

  onSubmit():void
  {
    let data = {fullname:this.form.fullname,
                username:this.form.username,
                email:this.form.email,
                password:this.form.password,
                confirmpassword:this.form.confirmpassword
                }
    localStorage.setItem(this.form.username,JSON.stringify(data));

  }

}
