import { MatchingDirective } from './matching.directive';

describe('MatchingDirective', () => {
  it('should create an instance', () => {
    const directive = new MatchingDirective();
    expect(directive).toBeTruthy();
  });
});
