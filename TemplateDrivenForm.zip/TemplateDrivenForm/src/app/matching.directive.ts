import { Directive } from '@angular/core';

@Directive({
  selector: '[matching]'
})
export class MatchingDirective {

  constructor() { }

  


}
