import { Component ,OnInit} from '@angular/core';
import { BookService } from './book.service';
import { Books } from 'src/model/Books';

@Component({
  selector: 'app-root',
  template:`

    <app-comp1></app-comp1>
      <app-comp2></app-comp2>

      <hr>

      <ul *ngFor="let b of bk">
        <li>{{b.title}} - {{b.price}}</li>
      </ul>
  `,
  styles: ['']
})
export class AppComponent {
  title = 'ServiceDI';

    bk?:Books[] |any

  constructor(private bkserv:BookService)
  {

  }

  ngOnInit(): void
  {

     this.bk = this.bkserv.getBookInfo();
    console.log(this.bk);
  }

}
