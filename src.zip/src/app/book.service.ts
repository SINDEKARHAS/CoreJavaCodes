import { Injectable } from '@angular/core';
import { Books } from 'src/model/Books';


@Injectable({
  providedIn: 'root'
})
export class BookService
{
  bk?:Books[]

  constructor() {

    this.bk = [{title:'Harry Potter 1',price:1250},
              {title:'Harry Potter 2',price:1350},
              {title:'Harry Potter 3',price:1450},
              {title:'Harry Potter 4',price:1550}
             ];
   }

  getBookInfo()
  {
      return this.bk;
  }

}
