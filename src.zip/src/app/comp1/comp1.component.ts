import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';


@Component({
  selector: 'app-comp1',
  templateUrl: './comp1.component.html',
  styleUrls: ['./comp1.component.css']
})
export class Comp1Component implements OnInit {

  constructor(private myserv:MyserviceService)
  { }

  ngOnInit(): void
  {
      console.log("init of comp1 ");
     this.getfunccall();
  }


  getfunccall()
  {
    this.myserv.func1();
  }

}
