import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';


@Component({
  selector: 'app-comp2',
  templateUrl: './comp2.component.html',
  styleUrls: ['./comp2.component.css']
})
export class Comp2Component implements OnInit {

  constructor(private myserv :MyserviceService) { }

  ngOnInit(): void
  {
    console.log("init of const2")
    this.myserv.func1();
  }

}
