import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})


export class MyserviceService
{

  constructor() { }

  public func1():void
  {
   console.log("this func1 get called");
  }

}
