export class Books
{
    title?:string;
    price?:number;
}
